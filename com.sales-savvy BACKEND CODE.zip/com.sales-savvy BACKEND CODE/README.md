# Sales Savvy — Backend

Spring Boot REST API for the Sales Savvy e-commerce platform. Handles users, products, cart, orders, and **Razorpay** payment integration.

---

## Prerequisites

- **Java 17**
- **Maven** (or use the included Maven Wrapper: `./mvnw`)
- **MySQL** (running locally or remote; default port 3306)

---

## Local Setup

### 1. Clone or open the project

Ensure you have the `com.sales-savvy BACKEND CODE` folder.

### 2. Configure `application.properties` (required)

You **must** edit the configuration file before running the backend:

**File:** `src/main/resources/application.properties`

Update the following placeholders with your own values:

| Property | What to set |
|----------|-------------|
| `spring.datasource.url` | Replace `[Add_your_mysql_database_name]` with your MySQL database name. The URL uses `?createDatabaseIfNotExist=true` so the DB can be created if it doesn’t exist. |
| `spring.datasource.username` | Replace `[Add_your_mysql_username]` with your MySQL username. |
| `spring.datasource.password` | Replace `[Add_your_mysql_password]` with your MySQL password. |
| `razorpay.key.id` | Replace `[Add_you_razorpay_key_id]` with your **Razorpay Key ID**. |
| `razorpay.key.secret` | Replace `[Add_you_razorpay_key_secret]` with your **Razorpay Key Secret**. |

**Example (do not commit real credentials):**

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/sales_savvy_db?createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=your_mysql_password

razorpay.key.id      = rzp_test_xxxxxxxxxxxx
razorpay.key.secret  = your_razorpay_secret
```

- **Razorpay:** You can create a **free test account** on the official Razorpay website and use the test Key ID and Secret for local development. See the root **PROJECT_OVERVIEW.md** for the link and more details.

### 3. Start MySQL

Ensure MySQL is running and that the user has rights to create databases (if you rely on `createDatabaseIfNotExist=true`).

### 4. Build and run

From the backend project root (`com.sales-savvy BACKEND CODE`):

```bash
./mvnw spring-boot:run
```

Or, if you use Maven directly:

```bash
mvn spring-boot:run
```

The API will start at **http://localhost:8080**.

### 5. Verify

- Open http://localhost:8080 in a browser or use a tool like Postman.
- The frontend expects the backend at `http://localhost:8080`; keep it running while using the React app.

---

## Tech Stack

- **Java 17**
- **Spring Boot 4.x** (Web, Data JPA, DevTools)
- **MySQL** + JPA/Hibernate
- **Razorpay Java SDK** (payments)

---

## Main API Areas

- **Users:** sign-up, sign-in (e.g. `/signUp`, `/signIn`)
- **Products:** CRUD, list, search (e.g. `/getAllProducts`, `/addProduct`, `/updateProduct`, `/deleteProduct`, `/searchProduct`)
- **Cart:** get cart, add to cart (e.g. `/getCart/{username}`, `/addToCart`)
- **Payments:** create order, verify (e.g. `/payment/create`, `/payment/verify`)
- **Orders:** order summary (e.g. `/order/summary/{orderId}`)

Controllers use `@CrossOrigin("*")` for local frontend development.

---

## Troubleshooting

- **Database connection failed:** Check MySQL is running, and that `application.properties` has the correct URL, username, and password.
- **Razorpay errors:** Ensure you set `razorpay.key.id` and `razorpay.key.secret` in `application.properties` and that you use **test** keys in test mode.
- **Port 8080 in use:** Change the server port in `application.properties`, e.g. `server.port=8081`, and then update the frontend to use the new base URL.

For project structure, roles, and a high-level summary, see the root **PROJECT_OVERVIEW.md**.
