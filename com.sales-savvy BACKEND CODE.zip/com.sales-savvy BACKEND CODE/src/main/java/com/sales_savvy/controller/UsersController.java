package com.sales_savvy.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sales_savvy.entity.Users;
import com.sales_savvy.service.UsersService;

@CrossOrigin("*")
@RestController
public class UsersController {
	@Autowired
	UsersService service;
	
//	@PostMapping("/data")
//	public String data(@RequestBody String username) {
//	    System.out.print("Data received: " + username);
//	    return "Data received:"+username;
//	}
	
	@PostMapping("/signUp")
	public String signUp(@RequestBody Users user) {
		String message = "";
		String username = user.getUsername();
		System.out.println("........"+user);
		Users u = service.getUser(username);
		System.out.println("---------"+u);
		if (u == null) {
			service.signUp(user);
			message = "User created successfully!";
		} else {
			message = "User alredy exists!";
		}
		return message;
	}
	
	@PostMapping("/signIn")
	public String signIn(@RequestBody Users user) {
		String message = "";
		String username = user.getUsername();
		String password = user.getPassword();
		String role = user.getRole();
		Users u = service.getUser(username);

		if (u != null) {
	        if(password.equals(u.getPassword()) && role.equals(u.getRole())) {
				message = u.getRole();
				System.out.println("correct");
			}else {
				System.out.println("wrong");
				message = u.getRole();
			}
			
		} else {
			System.out.println("no user");
			message = "Please SignUp";
		}
		return message;
	}
	
}
