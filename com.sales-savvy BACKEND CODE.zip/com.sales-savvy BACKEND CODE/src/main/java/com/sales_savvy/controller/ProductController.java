package com.sales_savvy.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sales_savvy.entity.CartItem;
import com.sales_savvy.entity.Cart;
import com.sales_savvy.entity.Product;
import com.sales_savvy.entity.Users;
import com.sales_savvy.service.CartService;
import com.sales_savvy.service.ProductService;
import com.sales_savvy.service.UsersService;

@CrossOrigin("*")
@RestController
public class ProductController {
	@Autowired
	ProductService service;
	@Autowired
	UsersService uService;
	
	@Autowired
	CartService cService;
	
	@PostMapping("/addProduct")
	public String addProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}
	
	@GetMapping("/searchProduct")
	public Product searchProduct(@RequestParam long id) {
		return service.searchProduct(id);
	}
	
	@PostMapping("/updateProduct")
	public String updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}
	
	@GetMapping("/deleteProduct")
	public String deleteProduct(@RequestParam long id) {
		return service.deleteProduct(id);
	}
	
	@GetMapping("/getAllProducts")
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}
	
//	@PostMapping("/addToCart")
//	public String addToCart(@RequestBody CartData data) {
//		//username who added to the cart 
//		String username = data.getUsername();
//		Users user = uService.getUser(username);
//		
//		//user which is added the productid to the cart 
//		//productDetails will have that productid complete details
//		Long productID = data.getProductId();
//	    Product productDetails = service.searchProduct(productID);
//	    
//		Cart c = null;
//		
//		//Checking that if the user is not havig the cart in it we have to creat and add the product 
//		if(user.getCart() == null) {
//			c = new Cart();
//			c.setUser(user);
//		}else {
//			c = user.getCart();
//		}
//		
//		c.getProductList().add(productDetails);
//        cService.addCart(c); 
//	   
//	    return "Product added to cart successfully!";
//	}

	@PostMapping("/addToCart")
	public String addToCart(@RequestBody CartItem item) {
		Users user = uService.getUser(item.getUsername());
		if (user == null) return "user not found";

		Product product = service.searchProduct(item.getProductId());
		if (product == null) return "product not found";

		Cart cart = user.getCart();
		if (cart == null) {
			cart = new Cart();
			cart.setUser(user);
			cart.setCartItems(new ArrayList<>());
			user.setCart(cart);
			cService.addCart(cart);
		}

		List<CartItem> items = cart.getCartItems();
		if (items == null) {
			items = new ArrayList<>();
			cart.setCartItems(items);
		}

		boolean found = false;
		for (CartItem ci : items) {
			if (ci.getProduct().getId().equals(product.getId())) {
				ci.setQuantity(ci.getQuantity() + item.getQuantity());
				found = true;
				break;
			}
		}

		if (!found) {
			CartItem newItem = new CartItem();
			newItem.setCart(cart);
			newItem.setProduct(product);
			newItem.setQuantity(item.getQuantity());
			items.add(newItem);
		}

		cService.addCart(cart);
		return "cart added";
	}

	@GetMapping("/getCart/{username}")
	public List<CartItem> getCart(@PathVariable String username) {
		Users u = uService.getUser(username);
		if (u == null || u.getCart() == null) return new ArrayList<>();
		return u.getCart().getCartItems();
	}
}
