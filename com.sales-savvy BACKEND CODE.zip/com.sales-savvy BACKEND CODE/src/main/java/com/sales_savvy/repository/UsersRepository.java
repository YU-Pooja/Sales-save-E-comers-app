package com.sales_savvy.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sales_savvy.entity.Users;

public interface UsersRepository extends JpaRepository<Users, Long> {
	Users findByUsername(String username);
}
