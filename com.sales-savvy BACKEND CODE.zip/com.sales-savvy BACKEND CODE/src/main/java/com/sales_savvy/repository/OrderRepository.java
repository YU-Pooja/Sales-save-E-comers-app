package com.sales_savvy.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.sales_savvy.entity.Orders;
public interface OrderRepository extends JpaRepository<Orders,String>{}
