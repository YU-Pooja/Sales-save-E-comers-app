package com.sales_savvy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sales_savvy.entity.Users;
import com.sales_savvy.repository.UsersRepository;

@Service
public class UsersServiceImplementation implements UsersService {

	@Autowired
	UsersRepository repo;
	
	public void signUp(Users user) {
		repo.save(user);
	}

	@Override
	public Users getUser(String username) {
		return repo.findByUsername(username);
	}
}
