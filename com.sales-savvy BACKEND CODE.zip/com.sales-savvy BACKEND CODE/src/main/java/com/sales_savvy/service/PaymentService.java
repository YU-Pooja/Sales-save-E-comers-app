package com.sales_savvy.service;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;

@Service
public class PaymentService {

    @Value("${razorpay.key.id}")
    private String keyId;
    
    @Value("${razorpay.key.secret}")
    private String keySecret;
    
    private RazorpayClient client;

    /* -------------------------------------------------------------
     * 1. Create a Razorpay order
     * ------------------------------------------------------------- */
    public Order createRzpOrder(int amountInPaise) throws RazorpayException {
        if (client == null) {
            client = new RazorpayClient(keyId, keySecret);
        }
        
        JSONObject options = new JSONObject();
        options.put("amount", amountInPaise);       // in paise
        options.put("currency", "INR");
        options.put("receipt", "order_rcpt_" + System.currentTimeMillis());
        
        return client.orders.create(options);
    }

    /* -------------------------------------------------------------
     * 2. Verify Razorpay signature
     * ------------------------------------------------------------- */
    public boolean verifySignature(String orderId, String paymentId, String signature) 
            throws RazorpayException {
        if (client == null) {
            client = new RazorpayClient(keyId, keySecret);
        }
        
        JSONObject options = new JSONObject();
        options.put("razorpay_order_id", orderId);
        options.put("razorpay_payment_id", paymentId);
        options.put("razorpay_signature", signature);
        
        try {
            Utils.verifyPaymentSignature(options, keySecret);  // throws if mismatch
            return true;
        } catch (RazorpayException e) {
            return false;
        }
    }

    /* -------------------------------------------------------------
     * 3. Expose the public key to the frontend
     * ------------------------------------------------------------- */
    public String getKeyId() {
        return keyId;
    }
}
