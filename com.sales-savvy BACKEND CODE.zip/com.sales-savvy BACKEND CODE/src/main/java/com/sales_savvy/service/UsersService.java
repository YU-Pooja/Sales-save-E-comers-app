package com.sales_savvy.service;

import com.sales_savvy.entity.Users;

public interface UsersService {
 
	void signUp(Users user); // used to signUp
	Users getUser(String username); //used to check wether we have the given user existing or not 
}
