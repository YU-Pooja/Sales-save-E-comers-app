package com.sales_savvy.service;

import java.util.List;

import com.sales_savvy.entity.Product;

public interface ProductService {

	String addProduct(Product product);
	
	Product searchProduct(Long id);
	Product searchProduct(String name);
	Product searchProductByCategory(String category);

	String updateProduct(Product product);
	
	String deleteProduct(Long id);
	
	List<Product> getAllProducts();
}
