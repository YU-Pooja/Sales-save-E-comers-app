package com.sales_savvy.service;

import java.util.List;

import com.sales_savvy.entity.Cart;
import com.sales_savvy.entity.CartItem;

public interface CartService {
	void addCart(Cart cart);

	void clearCart(String username);

	List<CartItem> getItems(String username);
	
	List<CartItem> cloneItems(String username);

}
