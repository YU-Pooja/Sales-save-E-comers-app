# Payment Integration with Razorpay - Step-by-Step Guide

## Overview
This guide documents the implementation of Razorpay payment gateway integration into the Sales Savvy application. The commit `a8b8305` adds complete payment functionality including order creation, payment verification, and cart clearing after successful payment.

---

## 📋 Summary of Changes

### Files Modified (2)
1. `pom.xml` - Added Razorpay dependency
2. `src/main/java/com/salesSavvy/service/CartService.java` - Added new methods
3. `src/main/java/com/salesSavvy/service/CartServiceImplementation.java` - Implemented new methods
4. `src/main/resources/application.properties` - Added Razorpay credentials

### Files Created (6)
1. `src/main/java/com/salesSavvy/controller/PaymentController.java` - Payment endpoints
2. `src/main/java/com/salesSavvy/dto/PaymentRequest.java` - DTO for payment creation
3. `src/main/java/com/salesSavvy/dto/PaymentVerifyRequest.java` - DTO for payment verification
4. `src/main/java/com/salesSavvy/entity/Orders.java` - Order entity
5. `src/main/java/com/salesSavvy/repository/OrderRepository.java` - Order repository
6. `src/main/java/com/salesSavvy/service/PaymentService.java` - Payment business logic

---

## 🎯 Step-by-Step Implementation Guide

### **Step 1: Add Razorpay Dependency to pom.xml**

**What it does:** Adds the Razorpay Java SDK to your project dependencies.

**Location:** `pom.xml`

**Changes:**
```xml
<dependency>
    <groupId>com.razorpay</groupId>
    <artifactId>razorpay-java</artifactId>
    <version>1.4.5</version>
</dependency>
```

**Add this after the existing dependencies** (around line 64, after the lombok dependency).

**Why:** This library provides Java methods to interact with Razorpay's API for creating orders, verifying payments, etc.

---

### **Step 2: Configure Razorpay Credentials**

**What it does:** Stores your Razorpay API keys securely in application properties.

**Location:** `src/main/resources/application.properties`

**Changes:**
```properties
razorpay.key.id      = rzp_test_I20RWLJ6fWdYxZ
razorpay.key.secret  = ayC7bV3xtbkocPsbDqOq7oWK
```

**Add these lines at the end of the file.**

**Why:** These credentials authenticate your application with Razorpay. The `key.id` is shared with the frontend, while `key.secret` remains server-side only.

**⚠️ Security Note:** In production, use environment variables instead of hardcoding credentials.

---

### **Step 3: Create Orders Entity**

**What it does:** Defines the database table structure for storing order information.

**Location:** `src/main/java/com/salesSavvy/entity/Orders.java`

**Full Code:**
```java
package com.salesSavvy.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Orders {

    @Id                         // Razorpay order-id (e.g. "order_LuF...")
    private String id;
    
    private int amount;         // in paise
    private String currency;    // "INR"
    private String status;      // "CREATED" / "PAID"
    private String receipt;     // optional
    private String paymentId;   // Razorpay payment ID after success
    
    @ManyToOne
    private Users user;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<CartItem> items;

    // Constructors
    public Orders() {
        super();
    }

    public Orders(String id, int amount, String currency, String status, 
                  String receipt, String paymentId, Users user, List<CartItem> items) {
        super();
        this.id = id;
        this.amount = amount;
        this.currency = currency;
        this.status = status;
        this.receipt = receipt;
        this.paymentId = paymentId;
        this.user = user;
        this.items = items;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReceipt() {
        return receipt;
    }

    public void setReceipt(String receipt) {
        this.receipt = receipt;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        return "Orders [id=" + id + ", amount=" + amount + ", currency=" + currency 
               + ", status=" + status + ", receipt=" + receipt + ", paymentId=" + paymentId 
               + ", user=" + user + ", items=" + items + "]";
    }
}
```

**Key Points:**
- `@Id` uses Razorpay's order ID as the primary key (String format)
- `amount` is stored in **paise** (1 INR = 100 paise)
- `status` tracks order lifecycle: "CREATED" → "PAID"
- `@ManyToOne` relationship with Users
- `@OneToMany` relationship with CartItems

---

### **Step 4: Create Order Repository**

**What it does:** Provides database access methods for Orders.

**Location:** `src/main/java/com/salesSavvy/repository/OrderRepository.java`

**Full Code:**
```java
package com.salesSavvy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.salesSavvy.entity.Orders;

public interface OrderRepository extends JpaRepository<Orders, String> {
}
```

**Key Points:**
- Extends `JpaRepository<Orders, String>` - note String type for ID (not Long)
- Provides built-in methods: `save()`, `findById()`, `findAll()`, etc.

---

### **Step 5: Create DTO Classes**

**What are DTOs?** Data Transfer Objects - simple classes to transfer data between frontend and backend.

#### **5A: PaymentRequest DTO**

**Location:** `src/main/java/com/salesSavvy/dto/PaymentRequest.java`

**Full Code:**
```java
package com.salesSavvy.dto;

public class PaymentRequest {
    public String username;
    public int amount;    // paise
    
    public PaymentRequest() {
        super();
    }
    
    public PaymentRequest(String username, int amount) {
        super();
        this.username = username;
        this.amount = amount;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public int getAmount() {
        return amount;
    }
    
    public void setAmount(int amount) {
        this.amount = amount;
    }
}
```

**Used for:** Creating a new Razorpay order (POST `/api/payment/create`)

---

#### **5B: PaymentVerifyRequest DTO**

**Location:** `src/main/java/com/salesSavvy/dto/PaymentVerifyRequest.java`

**Full Code:**
```java
package com.salesSavvy.dto;

public class PaymentVerifyRequest {
    public String username;
    public String orderId;
    public String paymentId;
    public String signature;
    
    public PaymentVerifyRequest() {
        super();
    }
    
    public PaymentVerifyRequest(String username, String orderId, String paymentId, String signature) {
        super();
        this.username = username;
        this.orderId = orderId;
        this.paymentId = paymentId;
        this.signature = signature;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    
    public String getPaymentId() {
        return paymentId;
    }
    
    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }
    
    public String getSignature() {
        return signature;
    }
    
    public void setSignature(String signature) {
        this.signature = signature;
    }
}
```

**Used for:** Verifying payment after user completes payment (POST `/api/payment/verify`)

---

### **Step 6: Update CartService Interface**

**What it does:** Adds methods to retrieve cart items and clear cart after payment.

**Location:** `src/main/java/com/salesSavvy/service/CartService.java`

**Changes:**
```java
package com.salesSavvy.service;

import java.util.List;
import com.salesSavvy.entity.Cart;
import com.salesSavvy.entity.CartItem;

public interface CartService {
    void addCart(Cart cart);
    
    // NEW METHODS:
    List<CartItem> getCartItems(String username);
    void clearCart(String username);
}
```

**Key Points:**
- `getCartItems()` - Fetches all items in a user's cart
- `clearCart()` - Removes all items after successful payment

---

### **Step 7: Update CartServiceImplementation**

**What it does:** Implements the new cart methods with database logic.

**Location:** `src/main/java/com/salesSavvy/service/CartServiceImplementation.java`

**Full Updated Code:**
```java
package com.salesSavvy.service;

import java.util.Collections;
import java.util.List;
import org.springframework.stereotype.Service;
import com.sales_savvy.entity.Cart;
import com.sales_savvy.entity.CartItem;
import com.sales_savvy.entity.Users;
import com.sales_savvy.repository.CartRepository;
import com.sales_savvy.repository.UsersRepository;

@Service
public class CartServiceImplementation implements CartService {

    private final CartRepository cartRepo;
    private final UsersRepository usersRepo;

    public CartServiceImplementation(CartRepository cartRepo, UsersRepository usersRepo) {
        this.cartRepo = cartRepo;
        this.usersRepo = usersRepo;
    }

    @Override
    public void addCart(Cart cart) {
        cartRepo.save(cart);
    }

    @Override
    public List<CartItem> getCartItems(String username) {
        Users user = usersRepo.findByUsername(username);
        if (user == null || user.getCart() == null) {
            return Collections.emptyList();
        }
        return user.getCart().getCartItems();
    }

    @Override
    public void clearCart(String username) {
        Users user = usersRepo.findByUsername(username);
        if (user != null && user.getCart() != null) {
            Cart c = user.getCart();
            c.getCartItems().clear();
            c.setTotalPrice(0);
            cartRepo.save(c);
        }
    }
}
```

**Key Points:**
- Uses constructor injection instead of `@Autowired`
- `getCartItems()` returns empty list if user/cart not found
- `clearCart()` removes all items and resets total price to 0

---

### **Step 8: Create PaymentService**

**What it does:** Contains all Razorpay integration logic - the core payment business logic.

**Location:** `src/main/java/com/salesSavvy/service/PaymentService.java`

**Full Code:**
```java
package com.salesSavvy.service;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;

@Service
public class PaymentService {

    @Value("${razorpay.key.id}")
    private String keyId;
    
    @Value("${razorpay.key.secret}")
    private String keySecret;
    
    private RazorpayClient client;

    /* -------------------------------------------------------------
     * 1. Create a Razorpay order
     * ------------------------------------------------------------- */
    public Order createRzpOrder(int amountInPaise) throws RazorpayException {
        if (client == null) {
            client = new RazorpayClient(keyId, keySecret);
        }
        
        JSONObject options = new JSONObject();
        options.put("amount", amountInPaise);       // in paise
        options.put("currency", "INR");
        options.put("receipt", "order_rcpt_" + System.currentTimeMillis());
        
        return client.orders.create(options);
    }

    /* -------------------------------------------------------------
     * 2. Verify Razorpay signature
     * ------------------------------------------------------------- */
    public boolean verifySignature(String orderId, String paymentId, String signature) 
            throws RazorpayException {
        if (client == null) {
            client = new RazorpayClient(keyId, keySecret);
        }
        
        JSONObject options = new JSONObject();
        options.put("razorpay_order_id", orderId);
        options.put("razorpay_payment_id", paymentId);
        options.put("razorpay_signature", signature);
        
        try {
            Utils.verifyPaymentSignature(options, keySecret);  // throws if mismatch
            return true;
        } catch (RazorpayException e) {
            return false;
        }
    }

    /* -------------------------------------------------------------
     * 3. Expose the public key to the frontend
     * ------------------------------------------------------------- */
    public String getKeyId() {
        return keyId;
    }
}
```

**Key Methods Explained:**

1. **`createRzpOrder()`**
   - Creates an order in Razorpay's system
   - Takes amount in paise (e.g., 50000 paise = ₹500)
   - Returns Order object with `id`, `amount`, `currency`, etc.

2. **`verifySignature()`**
   - Verifies payment authenticity using signature
   - Prevents payment tampering/fraud
   - Returns `true` if signature is valid

3. **`getKeyId()`**
   - Returns public Razorpay key for frontend
   - Safe to expose (not the secret key)

---

### **Step 9: Create PaymentController**

**What it does:** Exposes REST API endpoints for payment operations.

**Location:** `src/main/java/com/salesSavvy/controller/PaymentController.java`

**Full Code:**
```java
package com.salesSavvy.controller;

import java.util.Map;

import org.springframework.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.razorpay.Order;
import com.razorpay.RazorpayException;
import com.salesSavvy.dto.PaymentRequest;
import com.salesSavvy.dto.PaymentVerifyRequest;
import com.salesSavvy.entity.Orders;
import com.salesSavvy.entity.Users;
import com.salesSavvy.repository.OrderRepository;
import com.salesSavvy.service.CartService;
import com.salesSavvy.service.PaymentService;
import com.salesSavvy.service.UsersService;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin
public class PaymentController {

    @Autowired private PaymentService payService;
    @Autowired private UsersService usersService;
    @Autowired private OrderRepository orderRepo;
    @Autowired private CartService cartService;

    @PostMapping("/create")
    public ResponseEntity<?> createOrder(@RequestBody PaymentRequest req) throws RazorpayException {
        
        Users u = usersService.getUser(req.username);
        if (u == null) return ResponseEntity.badRequest().body("user not found");

        Order rzp = payService.createRzpOrder(req.amount);

        Orders o  = new Orders();
        o.setId(rzp.get("id"));
        o.setAmount(req.amount);
        o.setCurrency("INR");
        o.setStatus("CREATED");
        o.setUser(u);

        orderRepo.save(o);
        return ResponseEntity.ok(o);
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verifyPayment(@RequestBody PaymentVerifyRequest req) 
            throws RazorpayException {
        
        if (!payService.verifySignature(req.orderId, req.paymentId, req.signature))
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("signature mismatch");

        Orders ord = orderRepo.findById(req.orderId).orElseThrow();
        ord.setStatus("PAID");
        ord.setPaymentId(req.paymentId);
        orderRepo.save(ord);

        cartService.clearCart(req.username);   // empty cart

        return ResponseEntity.ok(ord.getId()); // for React redirect
    }

    @GetMapping("/key")
    public ResponseEntity<Map<String, String>> getKey() {
        return ResponseEntity.ok(Map.of("key", payService.getKeyId()));
    }
}
```

**API Endpoints:**

1. **POST `/api/payment/create`**
   - **Request Body:** `{ "username": "john", "amount": 50000 }`
   - **Response:** Order object with Razorpay order ID
   - **Flow:** 
     - Validates user exists
     - Creates Razorpay order
     - Saves order in database with status "CREATED"

2. **POST `/api/payment/verify`**
   - **Request Body:** `{ "username": "john", "orderId": "order_xyz", "paymentId": "pay_abc", "signature": "..." }`
   - **Response:** Order ID if successful
   - **Flow:**
     - Verifies payment signature
     - Updates order status to "PAID"
     - Clears user's cart
     - Returns order ID for redirect

3. **GET `/api/payment/key`**
   - **Response:** `{ "key": "rzp_test_..." }`
   - **Purpose:** Frontend needs this key to initialize Razorpay checkout

---

## 🔄 Payment Flow (Frontend to Backend)

### **Complete Payment Journey:**

```
1. USER CLICKS "CHECKOUT"
   ↓
2. Frontend → POST /api/payment/create
   Request: { username: "john", amount: 50000 }
   ↓
3. Backend creates Razorpay order
   Response: { id: "order_xyz123", amount: 50000, ... }
   ↓
4. Frontend → GET /api/payment/key
   Response: { key: "rzp_test_..." }
   ↓
5. Frontend opens Razorpay checkout with order_id and key
   ↓
6. USER COMPLETES PAYMENT in Razorpay popup
   ↓
7. Razorpay returns: orderId, paymentId, signature
   ↓
8. Frontend → POST /api/payment/verify
   Request: { username, orderId, paymentId, signature }
   ↓
9. Backend verifies signature
   ↓
10. If valid:
    - Update order status to "PAID"
    - Clear user's cart
    - Return success
```

---

## 🧪 Testing the Implementation

### **Test 1: Create Order**
```bash
curl -X POST http://localhost:8080/api/payment/create \
  -H "Content-Type: application/json" \
  -d '{"username": "testuser", "amount": 50000}'
```

**Expected Response:**
```json
{
  "id": "order_xyz123",
  "amount": 50000,
  "currency": "INR",
  "status": "CREATED",
  "user": {...}
}
```

### **Test 2: Get Razorpay Key**
```bash
curl http://localhost:8080/api/payment/key
```

**Expected Response:**
```json
{
  "key": "rzp_test_I20RWLJ6fWdYxZ"
}
```

### **Test 3: Verify Payment** (requires actual payment)
```bash
curl -X POST http://localhost:8080/api/payment/verify \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "orderId": "order_xyz123",
    "paymentId": "pay_abc456",
    "signature": "generated_by_razorpay"
  }'
```

---

## 📊 Database Changes

After running the application, Hibernate will create a new table:

### **`orders` Table Structure:**
```sql
CREATE TABLE orders (
    id VARCHAR(255) PRIMARY KEY,           -- Razorpay order ID
    amount INT NOT NULL,                   -- Amount in paise
    currency VARCHAR(10),                  -- "INR"
    status VARCHAR(20),                    -- "CREATED" or "PAID"
    receipt VARCHAR(255),                  -- Optional receipt number
    payment_id VARCHAR(255),               -- Razorpay payment ID (after payment)
    user_id BIGINT,                        -- Foreign key to users table
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```